package com.example.streamingapp_p5.models;

// FilmAdapter.java, replace with your actual package

public class Film {
    private int id;
    private String title;
    private String genre;
    private String realisateurs;
    private String description;
    private String imgpath;   // image URL
    private String trailer;   // trailer URL

    public Film() {}

    // Add imgPath and trailer to your constructor if needed

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }

    public String getRealisateurs() { return realisateurs; }
    public void setRealisateurs(String realisateurs) { this.realisateurs = realisateurs; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getImgPath() { return imgpath; }
    public void setImgPath(String imgpath) { this.imgpath = imgpath; }

    public String getTrailer() { return trailer; }
    public void setTrailer(String trailer) { this.trailer = trailer; }

    private int available_copies; // or use Integer if your backend can send null

    public int getAvailable_copies() {
        return available_copies;
    }

    public void setAvailable_copies(int available_copies) {
        this.available_copies = available_copies;
    }

}

