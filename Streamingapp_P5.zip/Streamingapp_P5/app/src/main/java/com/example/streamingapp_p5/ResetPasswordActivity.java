package com.example.streamingapp_p5;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;

public class ResetPasswordActivity extends AppCompatActivity {

    private EditText inputToken, inputNewPassword, inputNewPasswordConfirm;
    private Button resetBtn;
    private static final String RESET_URL = "https://silence-stream.onrender.com/api/reset-password";

    // userId obtained from the reset link intent or fallback for testing
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        inputToken = findViewById(R.id.inputToken);
        inputNewPassword = findViewById(R.id.inputNewPassword);
        inputNewPasswordConfirm = findViewById(R.id.inputNewPasswordConfirm);
        resetBtn = findViewById(R.id.resetBtn);

        // Get userId from intent extras (passed from reset link)
        userId = getIntent().getStringExtra("userId");

        // Fallback userId for testing purposes if not passed by intent
        if (TextUtils.isEmpty(userId)) {
            userId = "your_known_test_user_id_here"; // Replace with actual test userId
            Log.w("ResetPassword", "userId missing in intent extras, using fallback");
        }
        Log.d("ResetPassword", "userId = " + userId);

        resetBtn.setOnClickListener(v -> {
            String token = inputToken.getText().toString().trim();
            String newPassword = inputNewPassword.getText().toString().trim();
            String newPasswordConfirm = inputNewPasswordConfirm.getText().toString().trim();

            if (TextUtils.isEmpty(userId) || TextUtils.isEmpty(token)
                    || TextUtils.isEmpty(newPassword) || TextUtils.isEmpty(newPasswordConfirm)) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!newPassword.equals(newPasswordConfirm)) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            }
            sendResetRequest(userId, token, newPassword);
        });
    }

    private void sendResetRequest(String userId, String token, String newPassword) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, RESET_URL,
                response -> Toast.makeText(this, "Password reset successful!", Toast.LENGTH_LONG).show(),
                error -> {
                    String msg;
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        msg = new String(error.networkResponse.data);
                    } else {
                        msg = error.getMessage();
                    }
                    Toast.makeText(this, "Reset failed: " + msg, Toast.LENGTH_LONG).show();
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String,String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }

            @Override
            public byte[] getBody() {
                try {
                    Map<String, String> params = new HashMap<>();
                    params.put("userId", userId);
                    params.put("token", token);
                    params.put("password", newPassword);
                    Gson gson = new Gson();
                    String requestBody = gson.toJson(params);
                    Log.d("ResetPasswordBody", requestBody); // for debugging
                    return requestBody.getBytes("utf-8");
                } catch (Exception e) {
                    e.printStackTrace();
                    return "{}".getBytes();  // Return empty JSON instead of null
                }
            }
        };

        // Add retry policy to avoid timeout issues
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,  // Timeout in milliseconds
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        Volley.newRequestQueue(this).add(stringRequest);
    }
}
