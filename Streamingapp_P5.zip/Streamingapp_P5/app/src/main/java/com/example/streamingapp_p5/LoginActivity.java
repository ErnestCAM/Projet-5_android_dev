package com.example.streamingapp_p5;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.example.streamingapp_p5.utils.SharedPrefManager;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    private EditText emailInput, passwordInput;
    private Button loginBtn;
    private TextView goToRegister;
    private SharedPrefManager sharedPrefManager;
    private RequestQueue requestQueue;
    private static final String LOGIN_URL = "https://silence-stream.onrender.com/api/login";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailInput = findViewById(R.id.emailInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginBtn = findViewById(R.id.loginBtn);
        goToRegister = findViewById(R.id.goToRegister);
        TextView forgotPasswordTextView = findViewById(R.id.textForgotPassword); // <-- Add this line

        sharedPrefManager = new SharedPrefManager(getApplicationContext());
        requestQueue = Volley.newRequestQueue(this);

        loginBtn.setOnClickListener(v -> loginUser());

        goToRegister.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, RegistrationActivity.class));
        });

        forgotPasswordTextView.setOnClickListener(v -> { // <-- Add this block
            startActivity(new Intent(LoginActivity.this, ForgotPasswordActivity.class));
        });
    }


    private void loginUser() {
        final String email = emailInput.getText().toString().trim();
        final String password = passwordInput.getText().toString().trim();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(LoginActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, LOGIN_URL,
                response -> {
                    try {
                        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
                        if (jsonObject.has("token")) {
                            String token = jsonObject.get("token").getAsString();
                            sharedPrefManager.saveToken(token);
                            Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                            // Navigate to next screen (Film List, for example)
                            startActivity(new Intent(LoginActivity.this, FilmListActivity.class));
                            finish();
                        } else if (jsonObject.has("message")) {
                            Toast.makeText(LoginActivity.this, jsonObject.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(LoginActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(LoginActivity.this, "Response parsing error", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Toast.makeText(LoginActivity.this, "Request error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }) {
            @Override
            public Map<String, String> getHeaders() {
                // Default headers, if any
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }

            @Override
            public byte[] getBody() {
                // Build JSON request body
                try {
                    Map<String, String> params = new HashMap<>();
                    params.put("email", email);
                    params.put("password", password);
                    Gson gson = new Gson();
                    String requestBody = gson.toJson(params);
                    return requestBody.getBytes("utf-8");
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }
        };

        requestQueue.add(stringRequest);
    }
}

