package com.example.streamingapp_p5.models;

public class Rental {
    private int id;
    private int user_id;
    private int film_id;
    private String rental_date;    // Use String to match JSON date format; parse as needed
    private String return_date;    // nullable, may be null if not returned
    private int retour_quantite;   // typically 0 or 1

    public Rental() {}

    public Rental(int id, int user_id, int film_id, String rental_date, String return_date, int retour_quantite) {
        this.id = id;
        this.user_id = user_id;
        this.film_id = film_id;
        this.rental_date = rental_date;
        this.return_date = return_date;
        this.retour_quantite = retour_quantite;
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public int getUser_id() {
        return user_id;
    }
    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getFilm_id() {
        return film_id;
    }
    public void setFilm_id(int film_id) {
        this.film_id = film_id;
    }

    public String getRental_date() {
        return rental_date;
    }
    public void setRental_date(String rental_date) {
        this.rental_date = rental_date;
    }

    public String getReturn_date() {
        return return_date;
    }
    public void setReturn_date(String return_date) {
        this.return_date = return_date;
    }

    public int getRetour_quantite() {
        return retour_quantite;
    }
    public void setRetour_quantite(int retour_quantite) {
        this.retour_quantite = retour_quantite;
    }
}

