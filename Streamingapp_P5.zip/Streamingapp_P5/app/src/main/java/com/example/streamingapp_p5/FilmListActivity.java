package com.example.streamingapp_p5;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.streamingapp_p5.adapters.FilmAdapter;
import com.example.streamingapp_p5.models.Film;
import com.example.streamingapp_p5.utils.SharedPrefManager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FilmListActivity extends AppCompatActivity implements FilmAdapter.OnFilmActionListener {

    private RecyclerView filmsRecyclerView;
    private FilmAdapter filmAdapter;
    private ArrayList<Film> filmList;
    private Map<Integer, Integer> rentedFilmMap = new HashMap<>(); // filmId -> rentalId
    private SharedPrefManager sharedPrefManager;

    private static final String FILMS_URL = "https://silence-stream.onrender.com/api/films";
    private static final String RENTALS_URL = "https://silence-stream.onrender.com/api/rentals";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_film_list);

        filmsRecyclerView = findViewById(R.id.filmRecyclerView);
        filmsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        filmList = new ArrayList<>();
        sharedPrefManager = new SharedPrefManager(this);

        filmAdapter = new FilmAdapter(filmList, this, rentedFilmMap, this);
        filmsRecyclerView.setAdapter(filmAdapter);

        ImageView profileLogo = findViewById(R.id.profileIcon);
        profileLogo.setOnClickListener(v -> startActivity(new Intent(FilmListActivity.this, ProfileActivity.class)));

        TextView historyLink = findViewById(R.id.textViewHistoryLink);
        historyLink.setOnClickListener(v -> startActivity(new Intent(FilmListActivity.this, RentalHistoryActivity.class)));

        // Floating logout button setup
        FloatingActionButton fabLogout = findViewById(R.id.fabLogout);
        fabLogout.setOnClickListener(v -> {
            new android.app.AlertDialog.Builder(FilmListActivity.this)
                    .setTitle("Confirm Logout")
                    .setMessage("Do you really want to log out?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        sharedPrefManager.clear(); // Clear session/token
                        Intent intent = new Intent(FilmListActivity.this, LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                    })
                    .setNegativeButton("No", null)
                    .show();
        });

        fetchFilms();
        fetchRentedFilms();
    }

    private void fetchFilms() {
        StringRequest request = new StringRequest(Request.Method.GET, FILMS_URL,
                response -> {
                    try {
                        JsonObject jsonResponse = JsonParser.parseString(response).getAsJsonObject();
                        filmList.clear();
                        if (jsonResponse.has("films")) {
                            JsonArray filmsArray = jsonResponse.getAsJsonArray("films");
                            for (int i = 0; i < filmsArray.size(); i++) {
                                Film film = new Gson().fromJson(filmsArray.get(i), Film.class);
                                filmList.add(film);
                            }
                        }
                        filmAdapter.notifyDataSetChanged();
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Error parsing films", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Failed to fetch films.", Toast.LENGTH_SHORT).show()
        ) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = sharedPrefManager.getToken();
                if (token != null) {
                    headers.put("Authorization", "Bearer " + token);
                }
                return headers;
            }
        };
        Volley.newRequestQueue(this).add(request);
    }

    private void fetchRentedFilms() {
        StringRequest request = new StringRequest(Request.Method.GET, RENTALS_URL,
                response -> {
                    try {
                        JsonObject json = JsonParser.parseString(response).getAsJsonObject();
                        rentedFilmMap.clear();
                        if (json.has("rentals")) {
                            JsonArray rentalsArr = json.getAsJsonArray("rentals");
                            for (int i = 0; i < rentalsArr.size(); i++) {
                                JsonObject rentalJson = rentalsArr.get(i).getAsJsonObject();
                                if (rentalJson.has("film_id") && rentalJson.has("id")) {
                                    int filmId = rentalJson.get("film_id").getAsInt();
                                    int rentalId = rentalJson.get("id").getAsInt();
                                    rentedFilmMap.put(filmId, rentalId);
                                }
                            }
                        }
                        filmAdapter.notifyDataSetChanged();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                },
                error -> {
                    // Optionally handle error
                }
        ) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = sharedPrefManager.getToken();
                if (token != null) {
                    headers.put("Authorization", "Bearer " + token);
                }
                return headers;
            }
        };
        Volley.newRequestQueue(this).add(request);
    }

    @Override
    public void onRentFilmConfirmed(int filmId) {
        StringRequest request = new StringRequest(Request.Method.POST, RENTALS_URL,
                response -> {
                    Toast.makeText(this, "Film rented successfully.", Toast.LENGTH_SHORT).show();
                    fetchFilms();
                    fetchRentedFilms();
                },
                error -> Toast.makeText(this, "Failed to rent film.", Toast.LENGTH_SHORT).show()
        ) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = sharedPrefManager.getToken();
                if (token != null) headers.put("Authorization", "Bearer " + token);
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }
            @Override
            public byte[] getBody() {
                Map<String, Integer> body = new HashMap<>();
                body.put("film_id", filmId);
                return new Gson().toJson(body).getBytes(java.nio.charset.StandardCharsets.UTF_8);
            }
        };
        Volley.newRequestQueue(this).add(request);
    }

    @Override
    public void onReturnFilmConfirmed(int filmId, int rentalId) {
        String url = RENTALS_URL + "/" + rentalId + "/return";
        StringRequest request = new StringRequest(Request.Method.PUT, url,
                response -> {
                    Toast.makeText(this, "Film returned successfully.", Toast.LENGTH_SHORT).show();
                    fetchFilms();
                    fetchRentedFilms();
                },
                error -> Toast.makeText(this, "Failed to return film.", Toast.LENGTH_SHORT).show()
        ) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = sharedPrefManager.getToken();
                if (token != null) headers.put("Authorization", "Bearer " + token);
                return headers;
            }
        };
        Volley.newRequestQueue(this).add(request);
    }
}
