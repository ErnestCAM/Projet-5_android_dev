package com.example.streamingapp_p5.models;

public class AuthResponse {
    private String token;

    public AuthResponse() {}

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
}
