package com.example.streamingapp_p5;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.streamingapp_p5.models.Film;
import com.example.streamingapp_p5.utils.SharedPrefManager;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class RentDetailsActivity extends AppCompatActivity {

    private TextView title, directors, genre, description, copies;
    private EditText copiesInput;
    private Button confirmRentBtn;
    private SharedPrefManager sharedPrefManager;
    private int filmId;
    private int availableCopies = 0;

    private static final String FILMS_DETAIL_URL = "https://silence-stream.onrender.com/api/films/";
    private static final String RENT_FILM_URL = "https://silence-stream.onrender.com/api/rentals";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rent_details);

        title = findViewById(R.id.textTitleDetail);
        directors = findViewById(R.id.textDirectorsDetail);
        genre = findViewById(R.id.textGenreDetail);
        description = findViewById(R.id.textDescriptionDetail);
        copies = findViewById(R.id.textCopiesDetail);
        copiesInput = findViewById(R.id.inputCopies);
        confirmRentBtn = findViewById(R.id.buttonConfirmRent);

        sharedPrefManager = new SharedPrefManager(this);

        filmId = getIntent().getIntExtra("film_id", -1);

        if (filmId != -1) {
            fetchFilmDetails(filmId);
        } else {
            Toast.makeText(this, "Invalid Film ID", Toast.LENGTH_SHORT).show();
            finish();
        }

        confirmRentBtn.setOnClickListener(v -> rentFilm());
    }

    private void fetchFilmDetails(int id) {
        StringRequest request = new StringRequest(Request.Method.GET, FILMS_DETAIL_URL + id,
                response -> {
                    try {
                        JsonObject jsonFilm = JsonParser.parseString(response).getAsJsonObject();
                        Film film = new Gson().fromJson(jsonFilm, Film.class);

                        title.setText(film.getTitle());
                        directors.setText("Directors: " + film.getRealisateurs());
                        genre.setText(film.getGenre());
                        description.setText(film.getDescription());

                        // Defensive check for available_copies field
                        availableCopies = film.getAvailable_copies() >= 0 ? film.getAvailable_copies() : 0;
                        copies.setText("Available copies: " + availableCopies);

                        // For debugging, optionally show available copies
                        // Toast.makeText(this, "Available Copies loaded: " + availableCopies, Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Error loading details", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Failed to fetch details", Toast.LENGTH_SHORT).show()
        ) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = sharedPrefManager.getToken();
                if (token != null) headers.put("Authorization", "Bearer " + token);
                return headers;
            }
        };
        Volley.newRequestQueue(this).add(request);
    }

    private void rentFilm() {
        String numCopiesStr = copiesInput.getText().toString().trim();

        if (TextUtils.isEmpty(numCopiesStr)) {
            Toast.makeText(this, "Enter number of copies", Toast.LENGTH_SHORT).show();
            return;
        }

        int numCopies;
        try {
            numCopies = Integer.parseInt(numCopiesStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Enter a valid numeric number of copies", Toast.LENGTH_SHORT).show();
            return;
        }

        if (numCopies <= 0) {
            Toast.makeText(this, "Number of copies must be greater than zero", Toast.LENGTH_SHORT).show();
            return;
        }

        if (numCopies > availableCopies) {
            Toast.makeText(this, "Requested copies exceed available copies (" + availableCopies + ")", Toast.LENGTH_SHORT).show();
            return;
        }

        // Send rent request
        StringRequest request = new StringRequest(Request.Method.POST, RENT_FILM_URL,
                response -> {
                    Toast.makeText(this, "Film rented successfully", Toast.LENGTH_SHORT).show();
                    finish(); // Go back to film list
                },
                error -> Toast.makeText(this, "Failed to rent film", Toast.LENGTH_SHORT).show()
        ) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = sharedPrefManager.getToken();
                if (token != null) headers.put("Authorization", "Bearer " + token);
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }

            @Override
            public byte[] getBody() {
                Map<String, Object> body = new HashMap<>();
                body.put("film_id", filmId);
                // Optionally, uncomment this if your backend supports quantity:
                // body.put("quantity", numCopies);
                return new Gson().toJson(body).getBytes(StandardCharsets.UTF_8);
            }
        };

        Volley.newRequestQueue(this).add(request);
    }
}
