package com.example.streamingapp_p5;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.HashMap;
import java.util.Map;

public class RegistrationActivity extends AppCompatActivity {

    private EditText nameInput, emailInput, passwordInput;
    private Button registerBtn;
    private static final String REGISTER_URL = "https://silence-stream.onrender.com/api/register";
    private RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        nameInput = findViewById(R.id.nameInput);
        emailInput = findViewById(R.id.emailInput);
        passwordInput = findViewById(R.id.passwordInput);
        registerBtn = findViewById(R.id.registerBtn);
        requestQueue = Volley.newRequestQueue(this);

        registerBtn.setOnClickListener(v -> registerUser());
    }

    private void registerUser() {
        final String name = nameInput.getText().toString().trim();
        final String email = emailInput.getText().toString().trim();
        final String password = passwordInput.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(RegistrationActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, REGISTER_URL,
                response -> {
                    try {
                        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
                        if (jsonObject.has("message")) {
                            Toast.makeText(RegistrationActivity.this, jsonObject.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                            if (jsonObject.get("message").getAsString().toLowerCase().contains("réussie")) {
                                finish(); // Registration successful, return to login
                            }
                        } else {
                            Toast.makeText(RegistrationActivity.this, "Registration response received", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(RegistrationActivity.this, "Response parsing error", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(RegistrationActivity.this, "Request error: " + error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String,String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }

            @Override
            public byte[] getBody() {
                try {
                    Map<String, String> params = new HashMap<>();
                    params.put("name", name);
                    params.put("email", email);
                    params.put("password", password);
                    Gson gson = new Gson();
                    String requestBody = gson.toJson(params);
                    return requestBody.getBytes("utf-8");
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }
        };

        requestQueue.add(stringRequest);
    }
}
