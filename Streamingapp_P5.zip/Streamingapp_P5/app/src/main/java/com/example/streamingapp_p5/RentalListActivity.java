package com.example.streamingapp_p5;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.streamingapp_p5.Rental.RentalAdapter;
import com.example.streamingapp_p5.models.Rental;
import com.example.streamingapp_p5.utils.SharedPrefManager;
import com.google.gson.*;
import java.util.*;

public class RentalListActivity extends AppCompatActivity {
    private RecyclerView rentalsRecyclerView;
    private RentalAdapter rentalAdapter;
    private ArrayList<Rental> rentalList;
    private SharedPrefManager sharedPrefManager;
    private static final String RENTALS_URL = "https://silence-stream.onrender.com/api/rentals";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rental_list);

        rentalsRecyclerView = findViewById(R.id.rentalsRecyclerView);
        rentalsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        rentalList = new ArrayList<>();
        rentalAdapter = new RentalAdapter(rentalList, this);
        rentalsRecyclerView.setAdapter(rentalAdapter);

        sharedPrefManager = new SharedPrefManager(this);
        fetchRentals();
    }

    private void fetchRentals() {
        StringRequest request = new StringRequest(Request.Method.GET, RENTALS_URL,
                response -> {
                    try {
                        JsonObject json = JsonParser.parseString(response).getAsJsonObject();
                        if (json.has("rentals")) {
                            JsonArray rentalsArr = json.getAsJsonArray("rentals");
                            rentalList.clear();
                            for (int i = 0; i < rentalsArr.size(); i++) {
                                Rental rental = new Gson().fromJson(rentalsArr.get(i), Rental.class);
                                rentalList.add(rental);
                            }
                            rentalAdapter.notifyDataSetChanged();
                        }
                    } catch (Exception e) { e.printStackTrace(); }
                },
                error -> Toast.makeText(this, "Could not fetch rentals", Toast.LENGTH_SHORT).show()
        ) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String,String> headers = new HashMap<>();
                String token = sharedPrefManager.getToken();
                if (token != null) headers.put("Authorization", "Bearer " + token);
                return headers;
            }
        };
        Volley.newRequestQueue(this).add(request);
    }
}
