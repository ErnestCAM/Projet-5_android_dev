package com.example.streamingapp_p5;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;

public class ForgotPasswordActivity extends AppCompatActivity {

    private EditText emailInput;
    private Button resetBtn;
    private RequestQueue requestQueue;
    private static final String FORGOT_PASSWORD_URL = "https://silence-stream.onrender.com/api/forgot-password";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        emailInput = findViewById(R.id.emailInput);
        resetBtn = findViewById(R.id.resetBtn);
        requestQueue = Volley.newRequestQueue(this);

        resetBtn.setOnClickListener(v -> {
            String email = emailInput.getText().toString().trim();
            if (TextUtils.isEmpty(email)) {
                Toast.makeText(ForgotPasswordActivity.this, "Please enter your email", Toast.LENGTH_SHORT).show();
            } else {
                sendResetRequest(email);
            }
        });
    }

    private void sendResetRequest(String email) {
        StringRequest request = new StringRequest(Request.Method.POST, FORGOT_PASSWORD_URL,
                response -> {
                    Toast.makeText(ForgotPasswordActivity.this, "Reset link sent. Check your email.", Toast.LENGTH_LONG).show();

                    // Pass email to ResetPasswordActivity
                    Intent intent = new Intent(ForgotPasswordActivity.this, ResetPasswordActivity.class);
                    intent.putExtra("userEmail", email);
                    startActivity(intent);
                },
                error -> Toast.makeText(ForgotPasswordActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String,String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }

            @Override
            public byte[] getBody() {
                try {
                    Map<String, String> params = new HashMap<>();
                    params.put("email", email);
                    Gson gson = new Gson();
                    String requestBody = gson.toJson(params);
                    return requestBody.getBytes("utf-8");
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }
        };

        requestQueue.add(request);
    }
}
