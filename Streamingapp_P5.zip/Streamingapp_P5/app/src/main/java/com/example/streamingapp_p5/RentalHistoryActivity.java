package com.example.streamingapp_p5;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.streamingapp_p5.Rental.RentalAdapter;
import com.example.streamingapp_p5.models.Rental;
import com.example.streamingapp_p5.utils.SharedPrefManager;
import com.google.gson.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class RentalHistoryActivity extends AppCompatActivity {

    private RecyclerView rentalHistoryRecyclerView;
    private RentalAdapter rentalAdapter;
    private ArrayList<Rental> rentalHistoryList;
    private SharedPrefManager sharedPrefManager;
    private static final String RENTAL_HISTORY_URL = "https://silence-stream.onrender.com/api/rentals/history";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rental_history);

        rentalHistoryRecyclerView = findViewById(R.id.rentalHistoryRecyclerView);
        rentalHistoryRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        rentalHistoryList = new ArrayList<>();
        rentalAdapter = new RentalAdapter(rentalHistoryList, this);
        rentalHistoryRecyclerView.setAdapter(rentalAdapter);

        sharedPrefManager = new SharedPrefManager(this);

        fetchRentalHistory();
    }

    private void fetchRentalHistory() {
        StringRequest request = new StringRequest(Request.Method.GET, RENTAL_HISTORY_URL,
                response -> {
                    try {
                        JsonObject json = JsonParser.parseString(response).getAsJsonObject();
                        if (json.has("history")) {
                            JsonArray historyArray = json.getAsJsonArray("history");
                            rentalHistoryList.clear();
                            Gson gson = new Gson();
                            for (int i = 0; i < historyArray.size(); i++) {
                                Rental rental = gson.fromJson(historyArray.get(i), Rental.class);
                                rentalHistoryList.add(rental);
                            }
                            rentalAdapter.notifyDataSetChanged();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(RentalHistoryActivity.this, "Error parsing response", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(RentalHistoryActivity.this, "Failed to load rental history", Toast.LENGTH_SHORT).show()
        ) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String,String> headers = new HashMap<>();
                String token = sharedPrefManager.getToken();
                if (token != null) headers.put("Authorization", "Bearer " + token);
                return headers;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }
}

