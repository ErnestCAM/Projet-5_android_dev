package com.example.streamingapp_p5;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class ResetLinkHandlerActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Uri data = getIntent().getData();
        if (data != null && data.getPath() != null && data.getPath().startsWith("/reset-password")) {
            String userId = data.getQueryParameter("id");
            String token = data.getQueryParameter("token");

            // Pass these to ResetPasswordActivity
            Intent intent = new Intent(this, ResetPasswordActivity.class);
            intent.putExtra("userId", userId);
            intent.putExtra("token", token);
            startActivity(intent);
        }
        finish();
    }
}
