package com.example.streamingapp_p5;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.example.streamingapp_p5.models.User;
import com.example.streamingapp_p5.utils.SharedPrefManager;
import java.util.HashMap;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity {

    private EditText profileName, profileEmail;
    private Button saveBtn;
    private SharedPrefManager sharedPrefManager;
    private static final String PROFILE_URL = "https://silence-stream.onrender.com/api/profile";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        profileName = findViewById(R.id.profileName);
        profileEmail = findViewById(R.id.profileEmail);
        saveBtn = findViewById(R.id.saveBtn);
        sharedPrefManager = new SharedPrefManager(this);

        loadProfile();

        saveBtn.setOnClickListener(v -> updateProfile());
    }

    private void loadProfile() {
        StringRequest request = new StringRequest(Request.Method.GET, PROFILE_URL,
                response -> {
                    try {
                        User user = new Gson().fromJson(response, User.class);
                        profileName.setText(user.getName());
                        profileEmail.setText(user.getEmail());
                    } catch (Exception e) { e.printStackTrace(); }
                },
                error -> Toast.makeText(this, "Load error", Toast.LENGTH_SHORT).show()
        ) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String,String> headers = new HashMap<>();
                String token = sharedPrefManager.getToken();
                if (token != null) headers.put("Authorization", "Bearer " + token);
                return headers;
            }
        };
        Volley.newRequestQueue(this).add(request);
    }

    private void updateProfile() {
        String name = profileName.getText().toString().trim();
        String email = profileEmail.getText().toString().trim();

        StringRequest request = new StringRequest(Request.Method.PUT, PROFILE_URL,
                response -> Toast.makeText(this, "Profile updated", Toast.LENGTH_SHORT).show(),
                error -> Toast.makeText(this, "Update error", Toast.LENGTH_SHORT).show()
        ) {
            @Override
            public Map<String,String> getHeaders() {
                Map<String,String> headers = new HashMap<>();
                String token = sharedPrefManager.getToken();
                if (token != null) headers.put("Authorization", "Bearer " + token);
                headers.put("Content-Type","application/json");
                return headers;
            }

            @Override
            public byte[] getBody() {
                // Only send changed fields if needed
                Map<String,String> map = new HashMap<>();
                map.put("name", name);
                map.put("email", email);
                return new Gson().toJson(map).getBytes();
            }
        };
        Volley.newRequestQueue(this).add(request);
    }
}
