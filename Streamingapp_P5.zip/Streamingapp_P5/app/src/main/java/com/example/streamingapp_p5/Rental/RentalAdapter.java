package com.example.streamingapp_p5.Rental;

// RentalAdapter.java
import android.content.Context;
import android.view.*;
import android.widget.Button;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.streamingapp_p5.R;
import com.example.streamingapp_p5.models.Rental;
import com.example.streamingapp_p5.utils.SharedPrefManager;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.*;

public class RentalAdapter extends RecyclerView.Adapter<RentalAdapter.ViewHolder> {

    private ArrayList<Rental> rentalList;
    private Context context;

    public RentalAdapter(ArrayList<Rental> rentalList, Context context) {
        this.rentalList = rentalList;
        this.context = context;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView rentalInfo;
        public Button returnBtn;
        public ViewHolder(View v) {
            super(v);
            rentalInfo = v.findViewById(R.id.rentalInfo);
            returnBtn = v.findViewById(R.id.returnBtn);
        }
    }

    @Override
    public RentalAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_rental_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder h, int pos) {
        Rental rental = rentalList.get(pos);
        h.rentalInfo.setText("Film ID: " + rental.getFilm_id() + "\nRented: " + rental.getRental_date());
        // Show button only if not returned
        h.returnBtn.setVisibility(rental.getRetour_quantite() == 0 ? View.VISIBLE : View.GONE);

        h.returnBtn.setOnClickListener(view -> {
            // Call return rental endpoint
            String RETURN_URL = "https://silence-stream.onrender.com/api/rentals/" + rental.getId() + "/return";
            SharedPrefManager spm = new SharedPrefManager(context);
            StringRequest req = new StringRequest(Request.Method.PUT, RETURN_URL,
                    resp -> {
                        h.returnBtn.setVisibility(View.GONE);
                    }, error -> {}) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> headers = new HashMap<>();
                    String token = spm.getToken();
                    if (token != null) headers.put("Authorization", "Bearer " + token);
                    return headers;
                }
            };
            Volley.newRequestQueue(context).add(req);
        });
    }

    @Override
    public int getItemCount() {
        return rentalList.size();
    }
}
