package com.example.streamingapp_p5;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class TrailerActivity extends AppCompatActivity {

    public static final String EXTRA_TRAILER_URL = "extra_trailer_url";
    private WebView webView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trailer);

        webView = findViewById(R.id.webview_trailer);

        String trailerUrl = getIntent().getStringExtra(EXTRA_TRAILER_URL);
        if (trailerUrl != null && !trailerUrl.isEmpty()) {
            WebSettings webSettings = webView.getSettings();
            webSettings.setJavaScriptEnabled(true);

            webView.setWebViewClient(new WebViewClient()); // Ensure links open in WebView

            webView.loadUrl(trailerUrl);
        } else {
            finish(); // Close if no URL passed
        }
    }
}
