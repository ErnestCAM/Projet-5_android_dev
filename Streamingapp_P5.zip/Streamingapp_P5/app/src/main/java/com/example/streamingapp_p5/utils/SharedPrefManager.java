package com.example.streamingapp_p5.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefManager {

    // Shared Preferences file name
    private static final String PREF_NAME = "streaming_app_prefs";

    // Keys
    private static final String KEY_TOKEN = "key_token";
    private static final String KEY_USER_NAME = "key_user_name";
    private static final String KEY_USER_EMAIL = "key_user_email";

    // Instance
    private SharedPreferences pref;
    private SharedPreferences.Editor editor;

    public SharedPrefManager(Context context) {
        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = pref.edit();
    }

    /**
     * Save JWT token
     */
    public void saveToken(String token) {
        editor.putString(KEY_TOKEN, token);
        editor.apply();
    }

    /**
     * Get JWT token
     */
    public String getToken() {
        return pref.getString(KEY_TOKEN, null);
    }

    /**
     * Save basic user info
     */
    public void saveUser(String name, String email) {
        editor.putString(KEY_USER_NAME, name);
        editor.putString(KEY_USER_EMAIL, email);
        editor.apply();
    }

    public String getUserName() {
        return pref.getString(KEY_USER_NAME, null);
    }

    public String getUserEmail() {
        return pref.getString(KEY_USER_EMAIL, null);
    }

    /**
     * Clear all stored data (logout)
     */
    public void clear() {
        editor.clear();
        editor.apply();
    }
}
