package com.example.streamingapp_p5;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.streamingapp_p5.utils.SharedPrefManager;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;

public class RentFilmActivity extends AppCompatActivity {

    private EditText filmIdInput;
    private Button rentFilmBtn;
    private SharedPrefManager sharedPrefManager;
    private static final String RENT_FILM_URL = "https://silence-stream.onrender.com/api/rentals";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rent_film);

        filmIdInput = findViewById(R.id.filmIdInput);
        rentFilmBtn = findViewById(R.id.rentFilmBtn);
        sharedPrefManager = new SharedPrefManager(this);

        rentFilmBtn.setOnClickListener(v -> rentFilm());
    }

    private void rentFilm() {
        final String filmIdStr = filmIdInput.getText().toString().trim();

        if (TextUtils.isEmpty(filmIdStr)) {
            Toast.makeText(this, "Please enter film ID", Toast.LENGTH_SHORT).show();
            return;
        }

        final int filmId;

        try {
            filmId = Integer.parseInt(filmIdStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Film ID must be a number", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest request = new StringRequest(Request.Method.POST, RENT_FILM_URL,
                response -> {
                    Toast.makeText(RentFilmActivity.this, "Film rented successfully", Toast.LENGTH_SHORT).show();
                    // Optionally clear input or navigate elsewhere
                    filmIdInput.setText("");
                },
                error -> {
                    Toast.makeText(RentFilmActivity.this,
                            "Failed to rent film: " + (error.getMessage() != null ? error.getMessage() : ""),
                            Toast.LENGTH_SHORT).show();
                }
        ) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String,String> headers = new HashMap<>();
                String token = sharedPrefManager.getToken();
                if (token != null) headers.put("Authorization", "Bearer " + token);
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }

            @Override
            public byte[] getBody() {
                Map<String, Integer> body = new HashMap<>();
                body.put("film_id", filmId);
                return new Gson().toJson(body).getBytes();
            }
        };

        Volley.newRequestQueue(this).add(request);
    }
}
