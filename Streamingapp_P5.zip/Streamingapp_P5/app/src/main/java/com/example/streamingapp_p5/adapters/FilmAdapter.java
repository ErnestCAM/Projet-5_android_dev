package com.example.streamingapp_p5.adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.streamingapp_p5.R;
import com.example.streamingapp_p5.TrailerActivity;
import com.example.streamingapp_p5.models.Film;

import java.util.List;
import java.util.Map;

public class FilmAdapter extends RecyclerView.Adapter<FilmAdapter.FilmViewHolder> {

    public interface OnFilmActionListener {
        void onRentFilmConfirmed(int filmId);
        void onReturnFilmConfirmed(int filmId, int rentalId);
    }

    private final List<Film> films;
    private final Context context;
    private final Map<Integer, Integer> rentedFilmMap; // filmId -> rentalId
    private final OnFilmActionListener actionListener;

    public FilmAdapter(List<Film> films, Context context, Map<Integer, Integer> rentedFilmMap, OnFilmActionListener listener) {
        this.films = films;
        this.context = context;
        this.rentedFilmMap = rentedFilmMap;
        this.actionListener = listener;
    }

    public static class FilmViewHolder extends RecyclerView.ViewHolder {
        ImageView filmImage;
        TextView title, genre, description, directors, copies;
        Button rentButton, returnButton;
        public FilmViewHolder(@NonNull View itemView) {
            super(itemView);
            filmImage = itemView.findViewById(R.id.filmImage);
            title = itemView.findViewById(R.id.filmTitle);
            genre = itemView.findViewById(R.id.filmGenre);
            description = itemView.findViewById(R.id.filmDescription);
            directors = itemView.findViewById(R.id.filmDirectors);
            copies = itemView.findViewById(R.id.filmCopies);
            rentButton = itemView.findViewById(R.id.buttonRent);
            returnButton = itemView.findViewById(R.id.buttonReturn);
        }
    }

    @NonNull
    @Override
    public FilmViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.activity_film_item, parent, false);
        return new FilmViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull FilmViewHolder holder, int position) {
        Film film = films.get(position);

        holder.title.setText(film.getTitle());
        holder.genre.setText(film.getGenre());
        holder.description.setText(film.getDescription());
        holder.directors.setText("Directors: " + film.getRealisateurs());
        holder.copies.setText("Available copies: " + film.getAvailable_copies());

        // Load image
        String imageUrl = film.getImgPath();
        if (imageUrl != null && !imageUrl.trim().isEmpty()) {
            Glide.with(context).load(imageUrl)
                    .placeholder(R.drawable.activity_placeholder_image)
                    .error(R.drawable.activity_error_image)
                    .into(holder.filmImage);
        } else {
            holder.filmImage.setImageResource(R.drawable.activity_placeholder_image);
        }

        // Trailer click
        holder.filmImage.setOnClickListener(v -> {
            String trailerUrl = film.getTrailer();
            if (trailerUrl != null && !trailerUrl.isEmpty()) {
                Intent intent = new Intent(context, TrailerActivity.class);
                intent.putExtra(TrailerActivity.EXTRA_TRAILER_URL, trailerUrl);
                context.startActivity(intent);
            } else {
                Toast.makeText(context, "Trailer not available", Toast.LENGTH_SHORT).show();
            }
        });

        // Rental state logic
        final int filmId = film.getId();
        final boolean isRented = rentedFilmMap.containsKey(filmId);
        final Integer rentalId = rentedFilmMap.get(filmId);

        // Rent button
        holder.rentButton.setEnabled(!isRented && film.getAvailable_copies() > 0);
        holder.rentButton.setText(isRented ? "Already Rented" : (film.getAvailable_copies() > 0 ? "Rent" : "Not Available"));
        holder.rentButton.setOnClickListener((!isRented && film.getAvailable_copies() > 0) ? v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Rent Movie")
                    .setMessage("Do you want to rent \"" + film.getTitle() + "\"?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        if (actionListener != null) actionListener.onRentFilmConfirmed(filmId);
                    })
                    .setNegativeButton("No", null)
                    .show();
        } : null);

        // Return button
        holder.returnButton.setVisibility(isRented ? View.VISIBLE : View.GONE);
        holder.returnButton.setEnabled(isRented);
        holder.returnButton.setOnClickListener(isRented ? v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Return Movie")
                    .setMessage("Do you want to return \"" + film.getTitle() + "\"?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        if (actionListener != null && rentalId != null)
                            actionListener.onReturnFilmConfirmed(filmId, rentalId);
                    })
                    .setNegativeButton("No", null)
                    .show();
        } : null);
    }

    @Override
    public int getItemCount() { return films.size(); }
}
